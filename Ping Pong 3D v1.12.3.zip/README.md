# 🏓 Ping Pong 3D

**Ping Pong 3D** is a browser-based 3D table tennis game built with pure  
**JavaScript and Three.js**, featuring realistic physics and smooth gameplay.

The game runs entirely in the browser – no backend required.

---

## 🎮 Features
- Realistic ball physics (gravity, air drag, Magnus effect)
- Spin affecting ball trajectory and table bounces
- Dynamic ball deformation on impact
- AI opponent with multiple difficulty levels
- In-game shop (paddles & balls)
- Pause system with stats
- Real-time 3D rendering with shadows and materials

---

## 🕹️ Controls
- **A / D** – Move paddle left / right
- **ESC** – Pause game

---

## ⚙️ Technology Stack
- JavaScript (ES6)
- Three.js
- WebGL
- HTML5 / CSS3

---

